var cookieParser = require('cookie-parser');
var express = require('express');
var app = express();
var fs = require('fs');
var multer = require('multer');
app.use(cookieParser());
app.use(express.static('public'));
const cd = require('../companydata/lib/DataLayer');
const bl = require('../BusinessLayer/employeeVal.js');

/* GET employee */
app.get('/employees', function(req, res, next) {
    let empl = bl.checkEmployeesGet(req.body.company);
    var response;

    if (empl) {
        empl = cd.getAllEmployee(req.body.company);
        response = "[";

        empl.forEach(emp => {
            response += {
                empl_id: emp.empl_id,
                company: emp.company,
                empl_name: emp.empl_name,
                empl_no: emp.empl_no,
                location: emp.location
            } + ",";
        });

        response = response.substring(0, response.length - 1);

        response += "]";
    }
    else {
        response = {
            error: "No Employees Found"
        }
    }

    res.send(response);
});