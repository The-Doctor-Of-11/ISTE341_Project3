var cookieParser = require('cookie-parser');
var express = require('express');
var app = express();
var fs = require('fs');
var multer = require('multer');
app.use(cookieParser());
app.use(express.static('public'));
const cd = require('../companydata/lib/DataLayer');
const bl = require('../BusinessLayer/timecardVal.js');

/* GET department */
app.get('/timecards', function(req, res, next) {
    let timecd = bl.getAllTimecards(req.body.company);
    var response;

    if (timecd == null) {
        response = {
            error: "No Timecards Found"
        }
    }
    else {
        response = "[";

        timecd.forEach(tcd => {
            response += {
                timecd_id: tcd.timecd_id,
                company: tcd.company,
                timecd_name: tcd.timecd_name,
                timecd_no: tcd.timecd_no,
                location: tcd.location
            } + ",";
        });

        response = response.substring(0, response.length - 1);

        response += "]";
    }

    res.send(response);
});